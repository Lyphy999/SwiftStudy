class Hi {
    func sayHi(){
        print("hi")
    }
    
    class func he(){
        //这样定义 就是 类方法，类似于 java的 表态方法
        print("我是类方法")
    }
}

class SayHi : Hi{ //使用 : 来继承
    var _name:String
    init(name: String) {
        self._name = name
    }
    
    override func sayHi(){
        print("\(self._name) : say hi...")
    }
}

Hi.he()
let sayHi = SayHi(name: "a")
sayHi.sayHi()


//类功能 的动态扩展

extension Hi{
    func test()  {
       print("我是 Hi 的扩展方法")
    }
}

Hi().test()


class M{
//    var params: [String: String] {
//        return [String: String]()
//    }
    
    var params = [String : String]()
    var name: String{
        return ""
    }
}

M().params.updateValue("", forKey: "k")


let mapData = [String : String]()
//mapData.updateValue("", forKey: "kk")
