enum Direction{
    case north
    case south
    case east
    case west
}

enum Direction2{
    case north,south,east,west
}
//以上两种写法

var dir = Direction.west
dir = Direction.east
dir = .north //可以省略 枚举类
print(dir)

//: # 枚举类型 与其他类型的 关联存储在一起，会非常有用

enum Score{
    case point(Int)
    case grade(Character)
}

var score = Score.point(96)
score = .grade("A")

//枚举的 原始值： 枚举成员可以使用 相同类型 的默认值 预先关联，这个默认值叫做：原始值

enum PokerSuit : Character{//注意：这里并不是继承的意思,表示成员的 原始值为 字符类型
    case spade = "A"
    case heart = "d"
}

var suit = PokerSuit.spade
print(suit) // spade
print(suit.rawValue) // A

// 枚举 的隐式 原始值： 如果枚举的原始值类型 是 Int、String，Swift会自动 分配原始值
enum Dir : String{
    case north = "north"
    case south = "south"
}
//和下面是一样的定义
enum DirSame :String {
    case north, south //其中隐式的原始值就是 成员的名称
}
//如果 原始值是 Int ,则成员的隐式 原始值为 0、1、2、3 按顺序
//: # 递归枚举： 枚举类型里成员的 关联值又使用到了枚举类型,需要 加 indirect 关键字

indirect enum ArithExpr{
    case number(Int)
    case sum(ArithExpr,ArithExpr) //或者在这个成员前面 加 indirect 关键字
    case dif(ArithExpr,ArithExpr)
}

//: # MemoryLayout : 用来输出 数据类型的 内存

var age = 10
MemoryLayout<Int>.size //实际占用的内存大小 Int 类型占用多少字节 => 8
MemoryLayout<Int>.stride //分配 占用的内存大小
MemoryLayout<Int>.alignment //内存对齐 的字节数

MemoryLayout.size(ofValue: age) //查看 age变量占用多少内存 --> 8 （在 64位的架构下）

