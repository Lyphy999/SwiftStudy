//: [Previous](@previous)

import Foundation

var greeting = "Hello, playground"

//: [Next](@next)

class Data{
    init() {
        print(" data init")
    }
    
    func play() {
        print("data play")
    }
    
    
}

class Test{
//    var data = Data() //当初始化 Test后 [data]属性也会赋值，则可以使用延迟属性
    lazy var data = Data() //在使用时才会被初始化： 和 kotlin有不一样，kotlin 只能 lazy 常量
    init() {
        print(" Test init() ")
    }
}
var test = Test()
