//: [Previous](@previous)

import Foundation

var greeting = "Hello, playground"

//: [Next](@next)

class Student{
    private var name = "unknow"
    
    private var age = 0
    private var score = 0.0
    private var isPass = true
    
    /**
        静态属性，只属于结构体
     */
    public static let schoolName = "哈尔滨佛学院"
    convenience init() {
        //初始化方法
        //如果一个初始化器需要调用另一个初始化器，需要在前面加上 关键字: convenience
        self.init(name: "unknow",age: 0, score: 0.0)
    }
    
    init(name: String, age: Int, score: Double) {
        self.age = age
        self.name = name
        self.score = score
        isPass(score: score)
    }
    
    private func isPass(score:Double) {
        self.score = score
        if self.score < 60{
            self.isPass = false
        }
        else{
            self.isPass = true
        }
    }
    
    func getName() -> String {
        return self.name
    }
    
    public func setScore(score: Double){
        isPass(score: score)
    }
    
    public static func test(){
        //类的方法，实例不可调用
    }
    
    func setName(name: String)  {
        self.name = name
    }
    
}

var s1 = Student(name: "小工", age: 19, score: 90)

print("s1 name = \(s1.getName())")
var s2 = s1 // 类是 引用传递

s2.setName(name: "小要")
print(" s1 name 2 = \(s1.getName())") // s2 也修改了 s1的属性



//在类中和 在 结构体中使用 属性计算、下标语法、属性观察都一致


//Any 和 AnyObject: 所有 类的类型

var a: Any  = 1
print(type(of: a)) // Int

var p :Any = Student() // 还有结构体也属性 Any


//var b: AnyObject  = "dd"//错

var ss :AnyObject = Student() //对





