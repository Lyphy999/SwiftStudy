//: [Previous](@previous)

import Foundation

 

//: [Next](@next)

class Person{
    var age: Int = 0
    var name: String = ""
    var saraty:Double = 0 //属性也是一定要初始化
    init(name:String,age:Int) {
        self.name = name
        self.age = age
    }
    
    func getName() -> String {
        return self.name
    }
}

class Student: Person{
    override var name: String {
        //重写父类的 属性
        set{
            super.name = super.name + "- student" //newValue 这个是外部赋值传过来的
        }
        get{
            return super.name
        }
    }
    override init(name: String, age: Int) {
        //重写 初始化方法
        super.init(name: name, age: age)
        self.name = name
    }
    override func getName() -> String {//可以加 final 关键字，不让重写
        return super.getName() + "--> 被我重写了"
    }
}

var s = Student(name: "i", age: 99) //继承了父类 的初始化方法


//向下类型转换

var anyStu: Any = Student(name: "dd", age: 88)
//print(anyStu.getName()) // 父类并没有这个 方法，则需要 向下类型转换'

print(anyStu is Student)

var sss = anyStu as? Student //会是 可选类型

var sssss = anyStu as! Student // 如果明确

print( sss?.getName() ?? "ok")


// 000000000000000000000 类型判断和处理、对象相等性判断

class A{
    func printSelf() {
        print(type(of: self))
    }
}
class B: A{
    var name :String
    init(name:String) {
        self.name = name
    }
    
    func printName()  {
        print("")
    }
}

class C: A{
    var name: String
    init(name:String) {
        self.name = name
    }
    
    func printName() {
        print(" this is C printName() name= \(name)")
    }
}
var a1 = A()
var a2 = A()

print(a1 === a2) // 比较内存地址 == java/kotlin

print(a1 !== a2) // != java/kotlin

func getObj(param: Int) -> A{
    if(param > 10){
        return B(name: "小B")
    }else{
        return C(name: "小以")
    }
}

var obj = getObj(param: 10)
//对象判断

if let t1 = obj as? B {
    t1.printName()
    t1.printSelf()
}else if let t2 = obj as? C{
    t2.printName()
    t2.printSelf()
}


