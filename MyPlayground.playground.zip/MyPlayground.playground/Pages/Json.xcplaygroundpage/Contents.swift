//: [Previous](@previous)

import Foundation



//: [Next](@next)

struct Person: Codable{
    var name: String? = ""// 如果属性为 空，Json的处理不会 序列化该属性
    
    var age: Int = 0
    
    enum CodingKeys: String,CodingKey {
        case name = "pName"
        case age = "pAge"
    }
}

var p = Person()
p.name = "小李"
let jsonEncoder = JSONEncoder()
let result = try jsonEncoder.encode(p)
print(String(data: result, encoding: String.Encoding.utf8)!)

var mapData = [String : Any]() // 基本数据类型如果定义成 常量也不能调用其方法
mapData["s"] = "dd"

print(mapData)

var p2: Person? = Person()
p2?.name = "小哥"
print("---------------")

print(p2?.name) //Optional("小哥")

print(p2?.name ?? "") // 小哥// 如果有 ??后的 默认值，会解包



