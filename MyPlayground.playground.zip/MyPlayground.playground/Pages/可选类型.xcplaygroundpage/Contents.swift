//: [Previous](@previous)

import Foundation

var greeting = "Hello, playground"

//: [Next](@next)

//var a  = nil // 和 Kotlin类似，并不能直接给变量赋值 nil == null

var b: Int? = nil // 和 Kotlin 类似，在类型后面加 ？ 表示 可空的 Int 类型数据，在 Swift 里叫做 可选类型

print(b) // nil
print("b = \(b)")

var c: Int? = 10
print(c) // Optional(10)

print(Int("100")) // Optional(100)


