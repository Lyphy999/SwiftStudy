//: [Previous](@previous)

import Foundation

var greeting = "Hello, playground"

//: [Next](@next)

var s: Set = [1,3,3,4] // 无序不能重复
s.insert(5)

print(s)



// 字典

var d: Dictionary<String,String> = ["a":"A", "b": "B"]

var b:[Int: String] = [1:"a"]

var dic = [Int:String]()
dic.updateValue("ddd", forKey: 1)


for (a,b) in d{
    if(a == "a"){
        assert(true, "ddd")
    }
    print("a = " + a + " b = "+b)
}

//guard 语句

func test1(param: Int){
    guard param < 10 else {//满足条件时，不进入 else语句
        print("进入 guard 语句")
        return
    }
    print("hello world, 满足 guard 条件： \(param)")
}

test1(param: 10)
func test(){}

var fn: () -> Void = test
fn()

var fn2:() -> Void = {()->Void in // in 关键字不能省略
    print("匿名函数")
}

var fn3: ([Int]) -> String = {
    (ps: [Int] ) -> String in
    var temp: String = " - "
    for p in ps
    {
        temp +=  String(p)
    }
    return temp
}

var v = fn3([1,2,3333])
print("v = \(v)")



var a = {} //这个就是 匿名函数 且无 参数、无返回值

print(type(of: a)) //() -> ()

var fn4: () -> Void = {() -> Void in
    print("我是 匿名 函数")
}
//上面 这个可以简写为
fn4 = {
    print("我是它的简写...")
}
//fn4()

print("--------------------------")
func fn5(param:() -> Void){
    param()
}

fn5 {
    print("这就相当于闭包了")
}


func calc(fnParam: (Int, Int) -> Int){
    print(fnParam(10,20))
}
calc(fnParam: {$0 + $1})


