//: [Previous](@previous)

import Foundation

var greeting = "Hello, playground"

//: [Next](@next)
//: # 自动引用计数

class Test{
    var name: String
    init(name: String) {
        self.name = name
    }
    
    
    deinit {
        print("这就是反初始化器")
    }
    
}

var  t1: Test? = Test(name: "hello")// t1为引用，指向 一个 Test实例，引用计数加1， t1就是强引用

var t2 = t1 //引用计数加 1 //Optional<Test>
print(type(of: t2)) //Optional<Test>
var t3 = t1 //引用计数加 1
// 到上面为止，有 3个

//ARC工作机制： ,当没有任何引用指向一个实例时，那么这些个实例就会被销毁； 谁创建谁释放、谁引用管理

//反初始化器 deinit

t1 = nil
t2 = nil
t3 = nil


