//单行注释

import Foundation

/*
 多行注释;
 注释支持 markdown 语法,只在 playground 内有效
 ##
 */

//: # 一级标题, (加了冒号，则可以开启 markdown )

/*:
 
 */

let c: Int
c = 10


