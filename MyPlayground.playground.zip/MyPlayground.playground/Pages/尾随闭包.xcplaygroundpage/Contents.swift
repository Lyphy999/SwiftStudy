//: [Previous](@previous)

import Foundation

var greeting = "Hello, playground"

//: [Next](@next)
//: ## 尾随闭包： 当一个函数的最后一个参数是 函数类型时，在调用的时候则可以把函数的实现 挪到函数的括号外面去

func play1(p1: String, pFn: (String) -> Void){
    pFn(p1 + " swift")
}
//完整调用

//play1(p1: "hello", pFn: {(data: String) -> Void in
//    print(data)
//
//})
//闭包调用

play1(p1: "hell"){(data: String) in
    print(data)
}

print("------------------------------")

func play2(pFn: (String) -> String){
    let value = pFn("swift")
    
    print(" 返回值： "+value)
}

play2(){(data:String) -> String in
    
 
    return data + " ios"
}
//函数括号再省略
play2{(data) -> String in
    return  data + "ok"
}


