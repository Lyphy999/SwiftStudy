//: [Previous](@previous)

import Foundation

var greeting = "Hello, playground"

//: [Next](@next)

//类似 与 java/kotlin的 interface 接口

class TestClass{
    
}

protocol Protocol1{
    var a: Int { get set }
    var value1: String{
        set
        get //这样定义表示 该属性 可读、可写
    }
    
    func play1() -> String
}

protocol Protocol2{
    var value2: String {
        get //表可读
    }
    func  play2() -> String
}

class Data: TestClass,Protocol1,Protocol2{
    var a: Int = 0
    
    func play2() -> String {
        return self.value2
    }
    
    var value1: String //协议里的属性也要 重写 = ""
     init(n:String ) {
        self.value1 = n
    }
    func play1() -> String {
        return self.value1
    }
    
    var value2: String{
        set{
            
        }
        get{
            return "value 2"
        }
//        return " value2 "} //value1 在协议定义里定义 了 get,可读，但实现类具体的还是可以改变
    }
    
}

var d = Data(n: "dd")
d.value2 = "dd"

print(d.play2())


// 协议关联 类型

protocol Test{
    associatedtype D ///通过这个关键字来限制 协议中 函数的
    
    func play(param: D )
    
}


