//: [Previous](@previous)

import Foundation

var greeting = "Hello, playground"

//: [Next](@next)

//元组 类型： 类似 于 Kotlin中的 解构

var a = (1, 15,6,"hello", true)

print(a)
print(a.0)

a.0 = 99
var b: (Int, String) = (10, "Swift") //限定 元组中元素 类型的定义

let c = a //元组赋值

print("c = \(c)" )

//如果 元组 被定义 为 常量，则不能个性 元组中的元素

//c.0 = 99 //会报错 note: change 'let' to 'var' to make it mutable

var d: (age: Int, name: String) = (100,"hello")

print(d.age)

//将元组进行拆分

let (name1,name2) = ("swift", 1.5) //这里的 name1 name2 就是常量了
print(name1)

// 元组当前函数 的参数

func handle(params: (Int,String,Bool)) -> (Int,String,Bool){
    var result = params
    result.0 = params.0 + 1
    result.1 = params.1 + " world"
    result.2 = !params.2
    
    return result// 这点和 Kotlin 不同，不能以最后一行语句为返回值
}

var result = handle(params: (10,"hello", true))
print("result = \(result)")
