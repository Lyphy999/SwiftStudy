//: [Previous](@previous)

import Foundation

var greeting = "Hello, playground"

//: [Next](@next)

class Data{
    var name = ""
    
    init(name: String) {
        self.name = name
    }
    
    func play()  {
        print(self.name)
    }
}

class Test{
    var name = ""
    var data:Data? = nil
    init(name:String, data:Data) {
        self.name = name
        self.data = data
    }
    
    deinit {
        print("Test的实例 被释放 name = \(name)")
    }
}


var t: Test? = Test(name: "hello", data: Data(name: "world"))

t?.data?.play() // 就是类似于 kotlin的 ?.
t = nil
