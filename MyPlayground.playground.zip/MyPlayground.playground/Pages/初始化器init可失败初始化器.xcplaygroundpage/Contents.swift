//: [Previous](@previous)

import Foundation

var greeting = "Hello, playground"

//: [Next](@next)
class Test{
    var name: String
    
//    init(name:String) {
//        //普通 初始化器
//        self.name = name
//    }
    
    init?(name:String){ // init后面加了 ?号的表示 初始化可以失败，为nil
        if(name == "unknown"){
            return nil
        }
        self.name = name
    }
}


//var t = Test(name: "hello") //这样赋值结果就变成 可能为 nil的值 了，即可选
var t: Test? = Test(name: "u")
if let p = t {  // 这种 有点类似 于 kotlin的 t?.let{ }
 
    print(p.name)
}
else{
    print("初始化失败")
}

//必要初始化器 required; 结构体成员初始化器； 闭包设置属性初始值

class D{
    var name: String
    /* 即表示必要初始化器 */
    required init(name: String) {
        self.name = name
    }
}

class SubD: D{
//    required init(name: String) {
//        super.init(name: name)
//        self.name = name
//    }// 为什么没有要求 必须要写 父类的那个初始化器呢？？
    
    var score: Int = 0
}

var subD = SubD(name: "subD")
subD.score = 100
print("subD name = \(subD.name)") //正常输出
//: ## 结构体成员初始化器，表示如果是结构体的话，声明了多少个成员，即会自动有带成员参数的默认初始化器

struct SData{
    var name:String
    let age:Int
    
//    init(n:String,age:Int) {
//        self.name = n
//        self.age = age
//    }
}

//var sd = SData(n: "dd", age: 11)
var sd2 = SData(name: "dd", age: 99)//就会有默认的带成员名称参数的初始化器
print(sd2.age)

//闭包设置属性初始值

class CTestClose{
    var name:String = "" //属性如果没有初始化是不允许的，和 kotlin一致
    var age: Int = {
        var a = 10
        var b = 10
        return a + b
    }()//使用 闭包 + ()来对属性进行初始化
    
}

var c: CTestClose = CTestClose()
print(c.age)
