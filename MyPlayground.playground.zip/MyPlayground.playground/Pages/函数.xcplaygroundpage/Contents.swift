func pi() -> Double{
    return 3.14
}

//     注：形参 默认是 let,也只能是 let
func sum(v1: Int, v2: Int)-> Int{
//    return v1 + v2
    v1 + v2 //隐式 返回值
}

sum(v1: 2, v2: 3)// 函数调用时，不能省略参数名称，不同于Kotlin,但是可以在参数名称的前面加 _ 来达到 调用处省略参数名称的目的，但是不推荐,如下：
func sum2(_ v1: Int, _ v2: Int){
    
}
sum2(1, 2)//

//无返回值三种写法：

func sayHello(){
    
}

func say() -> Void{
    
}
func say3() -> (){
    //在这里 返回 () 相当于 空元组
}

//返回元组： 实现多返回值

func calculate(v1: Int, v2: Int) ->(sum: Int, dif: Int, average: Int){
    let sum = v2 + v1
    return (sum,v1-v2, sum >> 1)
}
calculate(v1: 1, v2: 4)

//函数 标签，可以在函数的参数名前加标签

func goToWork(at time: String){
    print("this time is \(time)")
}

goToWork(at: "08:00")// 函数标签 体现在 调用处，给人一种更容易读
// go to work at 08:00

//: # 默认参数值 (Default Parameter Value)

func check(name: String = "nobody", age: Int, job: String = "none"){
    
}

check(age: 18)
//C++ 的默认参数值有个限制：必须从右往左设置，由于 Swift拥有参数标签，因为并没有 此类限制，但是在省略参数标签时，需要特别注意，避免出错

//: # 可变参数
//注意点： 一个函数 最多只能有 1个可变参数
//紧跟在可变参数后面的参数不能省略标签
func sumss(_ num: Int...){
    //同 java ,相当于数组
}
sumss(1,111,22)

//输入、输出参数 ，关键字： inout,这样可以 修改 参数的值
//inout 修饰时，只能传递可以被多次赋值的参数

var number = 10
func test(_ num: inout Int){
    //inout 相当于 引用/地址 传递
    num = 20 //如果没有 inout 关键字，是不能修改参数的值的，因为是 let类型
}
test( &number)//但调用的时候，需要加 &

//函数重载 (Function OverLoad)
/**
  规则:
 函数名相同
 参数个数不同 || 参数类型不同 || 参数标签不同
 
 但与 返回值类型无关
 */

//内联 函数 (Inline Function)
//当一个 函数体的语句较少时，当编译器优化时，会直接调用 函数体
/**
   不会内联的情况：
 1、函数体内 递归调用自身
 2、动态派发
 3、函数体内语句太多：导致内联反而让汇编语句太多
 */

func test1(){
    print("test1")
}
test1() //编译器在 在开启了优化后(release 编译类型下默认开启)，会被优化成 直接 使用 test1()的函数体调用
//即 会直接 调用 print("test1")

// @inline 关键字
//永远不会被内联(即使开启了编译器优化)
@inline(never) func testInline(){}
//开启编译器优化后，即使函数体内代码很长，也会被内联(递归调用，动态派发除外)
@inline(__always) func testInline2(){}

//: ## 函数类型 (Function Type),每一个函数都是有类型的，函数类型由 形式参数类型、返回值类型 组成

func test3(){} //其函数类型为： -> Void 或者 ()->()

func b(a: Int, b: Int) -> Int{
    a + b
}// 其函数类型为： (Int,Int) -> Int

//有了函数 类型，则可以将 函数赋值给变量
//定义变量
var fn: (Int,Int) -> Int = b
fn(2,3) //5,调用时不需要参数标签

//函数类型 作为 函数参数

func sums(v1: Int, v2: Int) -> Int{
    v1 + v2
}

func dif(v1: Int,v2: Int) -> Int{
    v1 - v2
}
// _ mathFn 就是函数类型的形参
func calcResult(_ mathFn: (Int,Int)->Int, _ a: Int,_ b: Int){
    print("Result: \(mathFn(a,b))")
}

calcResult(sums, 3, 4)

//这样的话，函数类型可以为类的属性
//class Person{
//    var age:Int = 0
//    var fn: ()->()
//
//}

//同样，函数类型也可以作为 函数的返回值类型,该函数为高阶函数
func next(_ input: Int) -> Int{
    input + 1
}
func previous(_ input: Int) -> Int{
    input - 1
}

func forward(_ forward: Bool) -> (Int) -> Int{
    forward ? next :previous
}
forward(true)(3) // 4
forward(false)(3) //2

//: # typealias 用来给类型 起别名

typealias Byte = Int8
typealias Short = Int16
typealias Date = (year: Int, month: Int, day: Int)
func test33(_ date: Date){
    print(date.0)
    print(date.year)
}

typealias IntFn = (Int,Int) -> Int
// Void 就是空元组


//: # 函数 嵌套(Nested Function) : 将函数定义在 函数的内部

func nested(){
    func a(){}
    func b(){}
}

