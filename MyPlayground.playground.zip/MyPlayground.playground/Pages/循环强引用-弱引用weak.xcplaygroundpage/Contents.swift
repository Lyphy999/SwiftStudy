//: [Previous](@previous)

import Foundation

var greeting = "Hello, playground"

//: [Next](@next)

class TestA{
    var name = ""
     var ref:TestB? = nil
    init(name:String) {
        self.name = name
    }
    
    deinit {
        print(" TestA 的反 初始化器 name = \(name)")
    }
}

class TestB{
    var name = "TestB"
//     var ref:TestA? = nil //这种属于强引用
    weak var ref: TestA? = nil //变成 weak 弱引用后，就不会阻止 ARC的工作
    init(name:String) {
        self.name = name
    }
    
    deinit {
        print("TestB 的反初始化器，name = \(name)")
    }
}

var testA: TestA? = TestA(name: "A")

var testB: TestB? = TestB(name: "B")

testA!.ref = testB //如果没有加 weak; 这样就不会释放内存了，
testB!.ref = testA
testB = nil
testA = nil

//无主引用 unowned 关键字


