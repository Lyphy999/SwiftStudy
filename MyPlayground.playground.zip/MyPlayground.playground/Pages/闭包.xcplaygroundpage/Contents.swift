

let studname = { print("Swift 闭包实例") }
studname()

let divide = {(v1: Int, v2: Int) -> Int in return v1 / v2}

let result = divide(200,2)
