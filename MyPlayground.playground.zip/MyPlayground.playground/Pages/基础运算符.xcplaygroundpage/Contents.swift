//: [Previous](@previous)

import Foundation

var greeting = "Hello, playground"

//: [Next](@next)

// ?? 为合并运算符

var a = true
var b = !a //取反

//可选类型 绑定

var c: Int? = 10

if var value = c {//注意这里的 c没有使用 !号进行 解析值,这条 if的语义为： 如果 c有值
    print("value = \(value)")
    value = 90
}

// 可选 类型 的隐式展开

var d: Int! = 100 // ! 目的是可以让变量再可以 = nil
var e: Int = d //这里就会 隐式的展开 d 的值

print(e)

for i in 0 ..< 5 {
    print("i = \(i)")
}
