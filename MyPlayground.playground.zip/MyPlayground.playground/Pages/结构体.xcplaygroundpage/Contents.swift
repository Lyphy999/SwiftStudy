//: [Previous](@previous)

import Foundation

var greeting = "Hello, playground"

//: [Next](@next)

//: # 结构体 内部也可以有 函数 、属性, 属于 值类型，传递为值传递
struct Student{
    var name = "unknow"
    
    var age = 0
    var score = 0.0
    var isPass = true
    /**
        静态属性，只属于结构体
     */
    static let schoolName = "家里蹲大学"
    init() {
        //初始化方法
        
    }
    
    init(name: String, age: Int, score: Double) {
        self.age = age
        self.name = name
        self.score = score
    }
    func getName() -> String {
        return self.name
    }
    
    
    mutating func setScore(score: Double)  {
        self.score = score //要加 mutating 关键字才能设置 属性
    }
    
}

print(Student.schoolName)

var s = Student()
print(s.getName())


struct Test{
    var a = 10
}

var t1 = Test()
print( t1.a)
var t2 = t1 // 注意这里是值传递

t2.a = 100

print(" t2.a = \(t2.a)")
//但是 t1的 a 的值未改变,

let t3 = Test()

//t3.a = 100// 如果定义的是 常量，也不能改结构体里的变量

struct Person {
    private var value = ""
    var name: String{ //属性 有了 get 和 set;  类似于 Kotlin的 属性 get(){}; set(){}
        get{
          print("get")
            return value
        }
//        set(param){
//            print("set - " + param)
//        }
        //上面 的 参数可以省略，并且默认名称为 newValue
        
        set{
            print("set -- " + newValue)
        }
    }
    
    init() {
        
    }
    
}


//属性观察/监听

struct P{
    var name: String = "unknow"
    {
        willSet(new_value){
            print("willSet - " + new_value) //new_value 可以省略
        }
        didSet(old_value){
            print("didSet - " + old_value)//old_value 可以 省略
        }
    }
}
var p = P()

p.name = "hello" //就会调用 计算属性 name的 willSet() 以及 didSet()

print("-------------------------------------ddddddddddd")
// 下标语法 subscript

struct Human{
    private var array: [String] = ["swift","ios","macos"]
    
    subscript(index: Int, param: String) -> String{
        set(new_value){
            array.insert(new_value + param, at: index)
            print("set() new_value = \(new_value), index = \(index), param = \(param)")
        }
        get{
            print("get() index = \(index), param = \(param)")
            return array[index]
        }
    }
}

var h = Human()
//有了 下标语法后，就可以对结构体使用 类似于数组的方式一样

h[1,"A"] = "hello" //这里 hello 就对应 subscript() -> String 的 String

//访问 get

print(" xx = \(h[1,"ok"])")


