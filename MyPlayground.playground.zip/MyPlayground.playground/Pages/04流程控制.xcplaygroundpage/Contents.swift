// if else
/**
 if 后面的 小括号可以省略
 */
let a = 8
if a >= 9{
    
}

//while
var num = 5

while num > 0 {
    
    num -= 1 // num--, 是因为 Swift 把++,--去除了
}

//repeat //相当 于 do while

var num2 = -1
repeat{
    print(" num2 is \(num2)")
} while num > 0  //会输出一次

//for 循环

//闭区间运算符： a...b, a<= 取值  <= b
let names = ["and", "bb","cc","dd"]
    for i in 0...3 {
      print(names[i])
    }

let range = 1...3

for i2 in range {//这里的 i2 默认是常量
    print(names[i2])
}

//可以指定 i3为变量
for var i3 in 1...3{
    i3 += 5
    print(i3)
}

for a in 1...3{//在这里 a 没有被用到
    print("dd")
}
//常量没有用到的话，可以写成 _
for _ in 1...3{
    
}

//半开区间运算符: a..<b, a<= 取值 <b

//for -区间 运算符用在数组上
for name in names[0...3]{
    print(name)
}//

// 单侧区间： 让区间朝一个方向尽可能的远
for name1 in names[2...] {
    //区间的最大为数组的长度
}

for name2 in names[...2]{
    //最小为 0
}

let range1 = ...5 //这里就是负无穷小到 5

//区间类型
"cc"..."ff" // "cc" "cd" "cf" "cz"

let c: Character = "a"

let hour = 11
let hourInterval = 2
for tickMark in stride(from: 4, through: hour,by: hourInterval){
    print(tickMark)
}

//switch
// case 、 default 后面不能写 大括号，且必须要有至少一条语句
var number = 1
switch number {
case 1:
    print("number is 1")
//    break////// 这个 break 是可以不用写的，且不会贯穿到下下面的分支
case 2:
    print("number is 2")
    fallthrough // 这个关键字表示，可以贯穿到下面的分支，类似于java里的 case 1:
      //case 2:

default:
    print("number is other")
    break
}
//区间匹配、元组匹配

let count = 62
switch count {
case 0:
    print("none")
case 1..<5:
    print("a few ")
case 12..<100:
    print(" dozens of")
    break
default:
    print("many")
}

let point = (1,1)
switch point {
case (0,0):
    print("the origin")
case (_,1):
    
    break
default:
    print("outside of th box")
}

// 值绑定,
let point2 = (2,0)
switch point2 {
case (let x,0):// 当 0，匹配了后，这其中的 x会被赋值 上面的 2
    print(" ont the x-axis with an x value of \(x)")
default:
    
    break
        
}
//where 关键字

let point3 = (1,-1)
switch point3 {
case let (x,y) where x == y:
    print("on the line x==y")
case let (x,y) where x == -y:
    break
default:
    print("dd")
}

