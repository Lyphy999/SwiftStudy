let i: Int
i = 10
/**
  在 Swift 里， Int 不是基本数据类型，而是 结构体
 */



//: # 字面量

let bool = true // true为字面量，//取反是 false

let string = "小哥"

/**
  字符类型(可存储ASCII字符、Unicode 字符)
 */
let character: Character = "d"

//浮点数
let doubleDecimal = 123.0 //十进制，等价于 1.25e2;  0.0125 == 1.25e-2

let doubleHexadecimal1 = 0xFp2 // 十六进制，意味着 15 * 2^2,相当于十进制的 60.0

//数组

let array = [1,3,5,7,9]

//字典
let dictionary = ["age" : 18, "height" : 168]

//整数 转换,不同的类型不能直接相运算

let int1: UInt16 = 2_000
let int2: UInt8 = 1

//元组(tuple)

let http404Error = (404, "Not Found")
http404Error.0
http404Error.1

print("The status code is \(http404Error.0)")

let (code,msg) = http404Error //元组类型还可以这样赋值，类似于 Kotlin里的 解构
let (c, _) = http404Error

let http404Error2 = (code: 404,msg:"Not Found")

print(" error: \(http404Error2.code)")

let b = "10"

print(Int(b) ?? 100) //类似 于 Kotlin 中的 ?: 100
