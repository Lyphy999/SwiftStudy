//: [Previous](@previous)

import Foundation

var greeting = "Hello, playground"

//: [Next](@next)

class Test{
    var name = ""
    
    //fn 是一个函数 类型的变量
//     var fn: () -> Void = {() -> Void in
//        print(" 姓名 =" + self.name) //该 函数类型的 变量 这样子是不能访问 self的
//    }
    
   lazy var fn: () -> Void = {[unowned self]() -> Void in
       print(" 姓名 =" + self.name) //加 lazy,该 函数类型的 变更 就能访问 self的
   }
    
    init(name:String) {
        self.name = name
    }
    
    deinit {
        print("Test 的实例被释放，name = \(name)")
    }
}

var t: Test? = Test(name: "hello")
t!.fn() //会发现这样并不会让 t 释放， 因为 fn引用了 self,要解决的话
t = nil
