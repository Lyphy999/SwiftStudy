//: [Previous](@previous)

import Foundation

var greeting = "Hello, playground"

//: [Next](@next)

enum ErrorType: String,Error{
    case error1 = "错误1"
    case error2 = "错误2"
}

func doWork(param: Int) throws -> String{
    if param < 0 {
        throw ErrorType.error1
    }else if param > 1 && param <= 10{
        throw ErrorType.error2
    }
    print("正常执行")
    return "运行成功"
}

//try doWork(param: -10) //这样也行？？完整示例：
do {
   let value =  try doWork(param: 99)
    print("value = \(value)")
} catch ErrorType.error2 {
    print(" catch error2")
}
catch ErrorType.error1{
    print(" catch error1")
}
defer {
    print(" 相当 于 finally")
}
//如果不想捕捉 异常:
let result = try? doWork(param: -99)
print("result = \(result ?? "未运行成功")")
