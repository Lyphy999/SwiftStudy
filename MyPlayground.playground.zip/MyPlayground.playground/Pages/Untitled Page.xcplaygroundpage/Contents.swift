var a = 10
a = 20
a = 30
let b = 90
//
print("Hello,World")


print("hello,world")

import UIKit
import PlaygroundSupport

let view = UIView()
view.frame = CGRect(x:0,y: 0,width: 100,height: 100)
view.backgroundColor = UIColor.red
PlaygroundPage.current.liveView = view
