//: [Previous](@previous)

import Foundation

var greeting = "Hello, playground"

//: [Next](@next)

var a = [1,3,5]
print(a) // [1,3,5]

var b:[String] = ["hello","world"]
print(b) // ["hello", "world"]

var c:Array<Double> = [1.4, 56] //Array为结构体

print(c)

c[0] //取数组中的元素
c[0] = 13.3 //个性元素值

let d = [1,3] //如果是常量，则不能 追加也不能修改

var array = ["hello","a"]

array = array + ["ios","dd"]

array.append()
