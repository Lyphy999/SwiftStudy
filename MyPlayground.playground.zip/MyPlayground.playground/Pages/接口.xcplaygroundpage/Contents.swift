//接口： 使用关键字 protocol

protocol People{
    func getName() -> String
}

class Man: People{
    func getName() -> String {
        "张三"
    }
}

var m = Man()
print(" name is \(m.getName())")
