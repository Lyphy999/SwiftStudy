//: [Previous](@previous)

import Foundation

var greeting = "Hello, playground"

//: [Next](@next)

var str = "ABCDEF"
print("str's length = \(str.count)")

let startIndex = str.startIndex //这个是 Index 类型 // 1

let endIndex = str.endIndex //Index(_rawBits: 393217)

print("startIndex = \(startIndex),  endIndex = \(endIndex)")

print(str[startIndex]) // A

print(str[str.index(before: endIndex)]) //F

var a = str.index(startIndex, offsetBy: 2)

print(str[a])

str.contains("C") //判断是否包含字符

//遍历 字符串

for s in str {
    print("s  = \(s)")
}

var value = """
 hello
    swift
      dkdkk
 """

print("value = \(value)")

var  value1 = #"dddd"# // 以 #包裹 ，会把 ""也保留



